
function openNavBar() {
  document.body.classList.toggle("nav-open")
}

function closeNavBar() {
  document.body.classList.remove("nav-open")
}